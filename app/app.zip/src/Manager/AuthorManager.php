<?php

namespace App\Manager;

class AuthorManager extends BaseManager
{

}