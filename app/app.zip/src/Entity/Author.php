<?php

namespace App\Entity;

class Author
{

}