<h1>Un titre de home page</h1>

<?php
/**
 * @var $user \App\Entity\Author
 * @var $posts \App\Entity\Post[]
 */



echo $test;

?>